const getters = {
  domain: state => state.app.domain,
  user: state => state.app.user
};
// gettes should be a function
export default getters;
